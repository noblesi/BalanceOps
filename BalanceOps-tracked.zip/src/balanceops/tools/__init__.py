"""Developer tools for BalanceOps.

These modules are intended for local/CI utilities such as smoke checks and E2E one-shot runners.
"""
